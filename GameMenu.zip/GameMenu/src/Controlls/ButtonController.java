package Controlls;

import Scenes.*;
import javafx.scene.Scene;

public class ButtonController {
    static Scene currentScene = new Scene(Hauptmenu.createScene());

    public static void SingleplayerButton(){
        System.out.println("Singleplayer Button wurde gedrükt");
        currentScene = new Scene(Scenes.LevelSelection.createScene());
        Start.loadWindow();
    }
    public static void StartButton(){
        System.out.println("(Start) Button wurde gedrükt");
        //gameLoop.run(window)
    }
    public static void MultiplayerButton(){
        System.out.println("Mehrspieler Button wurde gedrükt");
        currentScene = new Scene(Scenes.Multiplayer.createScene());
        Start.loadWindow();
    }

    public static void HighscoreButton(){
        System.out.println("Highscore Button wurde gedrükt");
        currentScene = new Scene(Scenes.Highscore.createScene());
        Start.loadWindow();

    }
    public static void CharacterButton(){
        System.out.println("Character Button wurde gedrükt");
        currentScene = new Scene(Scenes.Character.createScene());
        Start.loadWindow();
    }

    public static void OptionsButton(){
        System.out.println("Options Button wurde gedrükt");
        currentScene = new Scene(Scenes.Option.createScene());
        Start.loadWindow();
    }

    public static void RestartButton(){
        System.out.println("Restart Scene wird geladen");
        currentScene = new Scene(Scenes.Restart.createScene());
        Start.loadWindow();
    }

    public static void MenuButton(){
        System.out.println("Zurück Button wurde gedrükt");
        currentScene = new Scene(Hauptmenu.createScene());
        Start.loadWindow();
    }

    public static void ExitButton(){
        System.out.println("Exit Button wurde gedrükt");
        System.exit(0);
    }

    public static Scene getCurrentScene(){
        return currentScene;
    }
}
