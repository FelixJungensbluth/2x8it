package Game;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Der Spieler und die Spieler wird hier erzeugt
 */
public class Player {

    public Rectangle pHBox;
    public Image playerImage;
    public ImageView playerImageView;

    /*
    Die HitBox für den Spieler wird erzeugt
     */
    public Rectangle createPlayerHitBox(){

        pHBox = new Rectangle(0, 500, 40, 60);
        pHBox.setFill(Color.rgb(255, 0, 0, 0.5));
            return pHBox;
    }

    public ImageView createPlayerImage() throws FileNotFoundException {

        playerImage = new Image("Images/chracter2.png");
        playerImageView = new ImageView(playerImage);
        playerImageView.setFitWidth(0);
        playerImageView.setFitHeight(0);
        playerImageView.setX(0);
        playerImageView.setY(500);
        playerImageView.setVisible(true);



        return playerImageView;


    }


}
