package Game;

import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.shape.Rectangle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Die GameObject Klasse behandelt die Spielmechaniken für den Spieler.
 */
public class GameObject {

    public int gravity;
    public int velocity;
    public int speedX = 20;
    public int speedY = 120;
    public boolean collision = false;
    public boolean canJump = false;
    public boolean moveRight = true;
    public boolean moveLeft = true;
    public boolean moveUp = false;
    public boolean moveDown = false;


    /**
     * Wenn der KeyInput einer der Tasten entspricht, und die Möglichkeit besteht, dass der Spieler sich nach rechts oder links bewegen kann und Springen kann,
     * wird die X oder Y Position um einen gewissen Wert verändert.
     * Dies erzeugt eine Bewugung des Spielers.
     * Dabei muss die Scene übergeben werden, auf welcher das Spiel statfindet, genauo wie die Hitbox des Spielers und das Player-Objekt.
     */

    public void createMovement(Scene scene, Rectangle hitbox, ImageView player) {
        moveRight = true;
        moveLeft = true;
        canJump = false;

        scene.setOnKeyPressed(ePress -> {
            KeyCode keycode = ePress.getCode();
            if (keycode.equals(KeyCode.D)  ) {
                if (moveUp ||moveLeft && hitbox.getX() <= 1235) {
                    hitbox.setX(hitbox.getX() + speedX);
                    player.setX(player.getX() + speedX);

                }

            }
            if (keycode.equals(KeyCode.A) ) {
                if (moveUp || moveRight && hitbox.getX() >= 5)  {
                    hitbox.setX(hitbox.getX() - speedX);
                    player.setX(player.getX() - speedX);
                }
            }
            if (keycode.equals(KeyCode.D) && ePress.isShiftDown() && canJump) {
                hitbox.setY(hitbox.getY() - speedY);
                player.setY(player.getY() - speedY);
                if (moveLeft && hitbox.getX() <= 1235) {
                    hitbox.setX(hitbox.getX() + speedX);
                    player.setX(player.getX() + speedX);
                }
            }


            if (keycode.equals(KeyCode.A) && ePress.isShiftDown() && canJump) {
                hitbox.setY(hitbox.getY() - speedY);
                player.setY(player.getY() - speedY);
                if (moveLeft && hitbox.getX() >= speedX) {
                    hitbox.setX(hitbox.getX() - speedX);
                    player.setX(player.getX() - speedX);
                }

                }

            if (keycode.equals(KeyCode.SPACE) && canJump) {
                hitbox.setY(hitbox.getY() - speedY);
                player.setY(player.getY() - speedY);
                }

            if (keycode.equals(KeyCode.W) && moveUp) {
                setGravity(0);
                setVelocity(0);
                hitbox.setY(hitbox.getY() - speedX);
                player.setY(player.getY() - speedX);
            }

            if (keycode.equals(KeyCode.S) && moveDown) {
                setGravity(0);
                setVelocity(0);
                hitbox.setY(hitbox.getY() + speedX);
                player.setY(player.getY() + speedX);
            }


        });

        /**
         * Wenn SPACE wieder losgelassen wurde wird die Gravitation und die Geschwindigkeit wieder auf den Normalwert gesetzt.
         * Dies erzeugt den Fall nach einem Sprung.
         */
        scene.setOnKeyReleased(eRel -> {
            KeyCode keycode = eRel.getCode();
            if (keycode.equals(KeyCode.SPACE)) {
                canJump = false;
                setGravity(0);
                setVelocity(0);
            }
        });

    }

    /**
     * Die Kollisionsabfarge basiert auf der BoundingBox berechnung.
     */
    public void createCollision(Rectangle player, Rectangle hb) {


        collision = player.getX() + player.getWidth() >= hb.getX()
                && player.getX() <= hb.getX() + hb.getWidth()
                && player.getY() + player.getHeight() >= hb.getY()
                && player.getY() <= hb.getY() + hb.getHeight();


        if (collision) {

            /*
            Kollision von unten
             */
            if (player.getY() <= hb.getY() - (player.getHeight())) {
                canJump = true;
                moveDown = false;
                moveLeft = true;
                setVelocity(0);
                setGravity(0);

                /*
                 Kollision von oben

                 */
            } else if (player.getY() >= hb.getY() + (hb.getHeight())) {
                canJump = false;
                moveRight = true;
                moveDown = true;
                moveLeft = true;


                /*
                Kollison von links
                 */
            } else if (player.getX() < hb.getX()) {
                moveRight = true;
                moveDown = true;
                moveLeft = false;

                /*
                Kollision von rechts
                 */
            } else if (player.getX() > hb.getX()) {
                moveRight = false;
                moveDown = true;
                moveLeft = true;
            } else {
                canJump = false;
            }
        }
    }

    /**
     * Das Bild für das Crosshair wird übergeben.
     */
    public Image crosshairImage() throws FileNotFoundException {
        Image cursor = new Image("Images/crosshair.png");
        return cursor;
    }

    /**
     * Die Werte für die Gravitation (Geschwindigkeit * Gravitationsfaktor) können gesetzt werden.
     */
    public void setVelocity(int vel) {
        velocity = vel;
    }

    public void setGravity(int grav) {
        gravity = grav;
    }
}




